from setuptools import setup

setup(

    name="paquetecalculos",
    version="1.0",
    description="paquete de redondeo y potencia",
    author="Erickson",
    author_email="ericksonvergararojas@hotmail.com",
    url="erickson-cir.webconde.com",
    packages=["calculos", "calculos.redondeos_potencias"]
)