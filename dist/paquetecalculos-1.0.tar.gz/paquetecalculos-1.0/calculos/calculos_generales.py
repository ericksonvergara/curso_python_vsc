def sumar(op1,op2):
    print("El resultado de la suma es: ", op1 + op2)

def resta(op1,op2):
    print("El resultado de la resta es: ", op1 - op2)

def multi(op1,op2):
    print("El resultado de la multiplicacione es: ", op1 * op2)

def division(op1,op2):
    print("El resultado de la division es: ", op1 / op2)

def potencia(base, exponente):
    print("El resultado es: ", base**exponente)

def redondear(numero):
    print("El resultado es: ", round(numero))
    
